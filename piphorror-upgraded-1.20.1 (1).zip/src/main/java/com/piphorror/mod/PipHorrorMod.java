package com.piphorror.mod;

import com.piphorror.mod.entity.PipEntity;
import com.piphorror.mod.init.ModEntities;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import software.bernie.geckolib.GeckoLib;

@Mod(PipHorrorMod.MOD_ID)
public class PipHorrorMod {
    public static final String MOD_ID = "piphorror";

    public PipHorrorMod() {
        GeckoLib.initialize();
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(modEventBus);
        modEventBus.addListener(this::registerAttributes);
    }

    @SubscribeEvent
    public void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.PIP.get(), PipEntity.createAttributes().build());
    }
}
